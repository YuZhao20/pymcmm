# pymcmm v0.2.0 GitHub プッシュ手順

## 概要

このドキュメントでは、pymcmm v0.2.0（Cython高速化版）をGitHubにプッシュする手順を説明します。

## ファイル構成

```
pymcmm/
├── .gitignore
├── LICENSE
├── README.md
├── CHANGELOG.md
├── requirements.txt
├── setup.py
├── pyproject.toml
├── mcmm/
│   ├── __init__.py
│   ├── model.py
│   └── _fast_core.pyx
└── tests/
    ├── __init__.py
    └── test_mcmm.py
```

## 手順

### 1. ローカルリポジトリの準備

```bash
# 既存のリポジトリに移動
cd /path/to/your/pymcmm

# 現在の状態を確認
git status

# 必要に応じてブランチを作成
git checkout -b v0.2.0-cython
```

### 2. ファイルの更新

zipファイルを展開して、ファイルを上書きします：

```bash
# バックアップ（念のため）
cp -r mcmm mcmm_backup_v0.1

# zipファイルを展開（pymcmm-v2.zipをダウンロード済みと仮定）
unzip pymcmm-v2.zip -d /tmp/
cp -r /tmp/pymcmm-v2/* .

# 不要なファイルを削除
rm -rf build/ mcmm/*.so mcmm/*.c
```

### 3. 変更の確認

```bash
# 差分を確認
git diff

# 新規ファイルを確認
git status
```

### 4. コミット

```bash
# 全ての変更をステージング
git add -A

# コミット
git commit -m "v0.2.0: Add Cython acceleration (35x speedup)

- Add Cython implementation for core math functions
- scipy.stats replacement for Student-t and normal distributions
- Automatic fallback to pure Python when Cython unavailable
- Add check_acceleration() and run_benchmark() functions
- Improve numerical stability
- Add comprehensive test suite
- Update documentation"
```

### 5. タグの作成

```bash
git tag -a v0.2.0 -m "Version 0.2.0 - Cython acceleration"
```

### 6. プッシュ

```bash
# mainブランチにマージする場合
git checkout main
git merge v0.2.0-cython

# プッシュ
git push origin main

# タグをプッシュ
git push origin v0.2.0
```

### 7. PyPIへの公開（オプション）

```bash
# ビルドツールをインストール
pip install build twine

# ソースディストリビューションを作成
python -m build --sdist

# PyPIにアップロード（テスト用）
twine upload --repository testpypi dist/*

# PyPIにアップロード（本番）
twine upload dist/*
```

## 注意事項

### Cythonビルドについて

- `.pyx`ファイルはソースとして含める
- `.c`ファイルと`.so`ファイルは`.gitignore`で除外
- ユーザーは自分の環境でビルドする必要がある

### 後方互換性

- v0.1.x からのAPI変更なし
- Cythonなしでも動作（純Python版にフォールバック）

### GitHub Release

1. GitHubのReleasesページに移動
2. "Draft a new release"をクリック
3. タグ`v0.2.0`を選択
4. リリースノート（CHANGELOG.mdの内容）を記載
5. 公開

## 確認項目

- [ ] 全てのテストがパスする
- [ ] README.mdが正しく表示される
- [ ] Cythonなしでもインストール・動作する
- [ ] Cythonありの場合35x高速化が確認できる
- [ ] バージョン番号が0.2.0になっている
